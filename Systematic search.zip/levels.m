for L = 1:26
    lev = -1:(2/(L-1)):1;
    lev = [L, lev]
end